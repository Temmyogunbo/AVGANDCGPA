import {
  createToken,
  createUser,
  findUser,
  login,
  signup,
} from "../../../src/api/user/user.resolvers";

describe("resolvers", () => {
  describe("Users", () => {
    it("should create token", () => {
      expect(true).toBe(true);
    });
  });
});
